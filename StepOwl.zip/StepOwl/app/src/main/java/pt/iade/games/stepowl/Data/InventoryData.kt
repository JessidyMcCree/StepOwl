package pt.iade.games.stepowl.Data

class InventoryData {
}